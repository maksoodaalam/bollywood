module.exports = {
  dataFileUploadPath: "../admin/public/uploads/temp",
  dataUploadLimitPerQuery: 10,
  cpuThreshold: 90,
  username: "root",
  password: "",
  database: "bollywood",
  host: "127.0.0.1",
  dialect: "mysql",
  //pagination
  defaultPageSize: 10,
  defaultPage: 1,
}